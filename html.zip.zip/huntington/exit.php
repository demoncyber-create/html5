<?php

header("Location: https://www.huntington.com/");

?>